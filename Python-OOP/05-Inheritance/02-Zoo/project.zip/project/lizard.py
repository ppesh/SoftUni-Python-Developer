#from zoo_2.project.reptile import Reptile
from project.reptile import Reptile


class Lizard(Reptile):
    pass