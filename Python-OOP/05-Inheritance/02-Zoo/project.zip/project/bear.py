#from zoo_2.project.mammal import Mammal
from project.mammal import Mammal


class Bear(Mammal):
    pass
