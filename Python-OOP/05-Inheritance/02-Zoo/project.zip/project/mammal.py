#from zoo_2.project.animal import Animal
from project.animal import Animal


class Mammal(Animal):
    pass


# mammal = Mammal("Stella")
# print(mammal.name())
