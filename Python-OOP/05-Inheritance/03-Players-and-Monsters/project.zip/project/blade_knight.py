#from players_and_monsters_3.project.dark_knight import DarkKnight
from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
	pass