#from restaurant_5.project.beverage.beverage import Beverage
from project.beverage.beverage import Beverage


class ColdBeverage(Beverage):
    pass


