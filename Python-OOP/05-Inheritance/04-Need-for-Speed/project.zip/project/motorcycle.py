#from need_for_speed_4.project.vehicle import Vehicle
from project.vehicle import Vehicle


class Motorcycle(Vehicle):
    pass


