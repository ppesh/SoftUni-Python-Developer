#from need_for_speed_4.project.car import Car
from project.car import Car


class FamilyCar(Car):
    pass


