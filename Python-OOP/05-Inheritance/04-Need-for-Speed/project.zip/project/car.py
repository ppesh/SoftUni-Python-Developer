#from need_for_speed_4.project.vehicle import Vehicle
from project.vehicle import Vehicle


class Car(Vehicle):
    DEFAULT_FUEL_CONSUMPTION = 3
    pass


