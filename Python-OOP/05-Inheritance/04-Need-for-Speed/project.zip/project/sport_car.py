#from need_for_speed_4.project.car import Car
from project.car import Car


class SportCar(Car):
    DEFAULT_FUEL_CONSUMPTION = 10
    pass
